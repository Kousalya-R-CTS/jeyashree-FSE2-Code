package com.socio.articleManagement.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Class Description
 *
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ErrorResponse 
{
	/**
	 * field description
	 */
	private Object data;
	/**
	 * field description
	 */
	private String statusCode;
	/**
	 * field description
	 */
	private List<String> message;
	
	/**
	 * default Constructor
	 */
	public ErrorResponse() {
		super();
	}
	/**
	 * method description
	 */
	public Object getData() {
		return data;
	}
	/**
	 * method description
	 */
	public void setData(Object data) {
		this.data = data;
	}
	/**
	 * method description
	 */
	public String getStatusCode() {
		return statusCode;
	}
	/**
	 * method description
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	/**
	 * method description
	 */
	public List<String> getMessage() {
		return message;
	}
	/**
	 * method description
	 */
	public void setMessage(List<String> message) {
		this.message = message;
	}
	
	
}
