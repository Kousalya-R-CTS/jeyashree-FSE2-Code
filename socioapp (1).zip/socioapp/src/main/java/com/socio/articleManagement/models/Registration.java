package com.socio.articleManagement.models;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author User
 *
 */
public class Registration {
	/**
	 * field description
	 */
	@JsonProperty("firstName")
	private String first_name;
	/**
	 * field description
	 */
	@JsonProperty("lastName")
	private String last_name;
	/**
	 * field description
	 */
	@JsonProperty("loginId")
	private String login_id;
	/**
	 * field description
	 */
	@JsonProperty("contactNumber")
	private String contact_number;
	/**
	 * field description
	 */
	@JsonProperty("email")
	private String email;
	/**
	 * field description
	 */
	@JsonProperty("password")
	private String password;
	/**
	 * field description
	 */
	@JsonProperty("status")
	private String status;
	/**
	 * field description
	 */
	@JsonProperty("loginTime")
	private String login_time;
	/**
	 * field description
	 */
	@JsonProperty("lastName")
	private String logoutTime;
	/**
	 * default constructor
	 */
	public Registration()
	{
		super();
	}
	/**
	 * @return the first_name
	 */
	@JsonProperty("firstName")
	public String getFirst_name() {
		return first_name;
	}
	/**
	 * @param first_name the first_name to set
	 */
	@JsonProperty("firstName")
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	/**
	 * @return the last_name
	 */
	@JsonProperty("lastName")
	public String getLast_name() {
		return last_name;
	}
	/**
	 * @param last_name the last_name to set
	 */
	@JsonProperty("lastName")
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	/**
	 * @return the login_id
	 */
	@JsonProperty("loginId")
	public String getLogin_id() {
		return login_id;
	}
	/**
	 * @param login_id the login_id to set
	 */
	@JsonProperty("loginId")
	public void setLogin_id(String login_id) {
		this.login_id = login_id;
	}
	/**
	 * @return the contact_number
	 */
	@JsonProperty("contactNumber")
	public String getContact_number() {
		return contact_number;
	}
	/**
	 * @param contact_number the contact_number to set
	 */
	@JsonProperty("contactNumber")
	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}
	/**
	 * @return the email
	 */
	@JsonProperty("email")
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	@JsonProperty("email")
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the password
	 */
	@JsonProperty("password")
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	@JsonProperty("password")
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the status
	 */
	@JsonProperty("status")
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	@JsonProperty("status")
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the login_time
	 */
	@JsonProperty("loginTime")
	public String getLogin_time() {
		return login_time;
	}
	/**
	 * @param login_time the login_time to set
	 */
	@JsonProperty("loginTime")
	public void setLogin_time(String login_time) {
		this.login_time = login_time;
	}
	/**
	 * @return the logoutTime
	 */
	@JsonProperty("logoutTime")
	public String getLogoutTime() {
		return logoutTime;
	}
	/**
	 * @param logoutTime the logoutTime to set
	 */
	@JsonProperty("logoutTime")
	public void setLogoutTime(String logoutTime) {
		this.logoutTime = logoutTime;
	}
	

}
