package com.socio.articleManagement.service;

import java.text.ParseException;
import java.util.List;

import com.socio.articleManagement.exception.BaseClassException;
import com.socio.articleManagement.models.ArticleStatusResponse;
import com.socio.articleManagement.models.ArticleStatusResponseDB;

/**
 * Interface IArticleService
 *
 */
public interface IArticleService
{
	/**
	 * method saveArticles - to create articles
	 * @param articleStatusResponse - articleStatusResponse
	 * @return articleStatusResponse - articleStatusResponse
	 * @throws BaseClassException - exception
	 * @throws ParseException 
	 */
	ArticleStatusResponse saveArticles(ArticleStatusResponse articleStatusResponse) throws BaseClassException, ParseException;
	/**
	 * method updateArticles - to update articles
	 * @param articleStatusResponse - articleStatusResponse
	 * @return articleStatusResponse - articleStatusResponse
	 * @throws BaseClassException - exception
	 */
	ArticleStatusResponse updateArticles(ArticleStatusResponse articleStatusResponse) throws BaseClassException;


	/**
	 * method deleteArticle - to delete article from DB
	 * @param id - id 
	 * @return boolean - result
	 * @throws BaseClassException - exception
	 */
	boolean deleteArticle(String id, String name) throws BaseClassException;
	/**
	 * method favouriteArticles - to like/dislike articles
	 * @param articleStatusResponse - articleStatusResponse
	 * @return ArticleStatusResponse - ArticleStatusResponse
	 * @throws BaseClassException - exception
	 */
	ArticleStatusResponse favouriteArticles(ArticleStatusResponse articleStatusResponse, String name) throws BaseClassException;
	/**
	 * method replyArticles - to reply articles
	 * @param articleStatusResponse - articleStatusResponse
	 * @return ArticleStatusResponse - ArticleStatusResponse
	 * @throws BaseClassException - exception
	 */
	ArticleStatusResponse replyArticles(ArticleStatusResponse articleStatusResponse) throws BaseClassException;
	/**
	 * method getUserArticles - to get user artciles from DB
	 * @param id - id 
	 * @param name - name
	 * @param threadId - threadId
	 * @return List<ArticleStatusResponse>  - list
	 * @throws BaseClassException - exception
	 */
	List<ArticleStatusResponseDB> getUserArticles(String id, String name, String threadId) throws BaseClassException;

	
}
