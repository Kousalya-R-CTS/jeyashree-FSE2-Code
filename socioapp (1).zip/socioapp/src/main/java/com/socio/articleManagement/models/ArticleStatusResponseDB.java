package com.socio.articleManagement.models;
import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Document(collection = "article_detail")
public class ArticleStatusResponseDB {
	@Id
	@JsonProperty("id")
    private String id;
    @JsonProperty("createdAt")
    private String createdAt;
    @JsonProperty("authorId")
    private String authorId;
    @JsonProperty("text")
    private String text;
    @JsonProperty("userIdMention")
    private String userIdMention;
    @JsonProperty("authorUserName")
    private String authorUserName;
    @JsonProperty("authorProfileUrl")
    private String authorProfileUrl;
    @JsonProperty("articleType")
    private String articleType;
    @JsonProperty("updatedAt")
    private String updatedAt;
    @JsonProperty("isActive")
    private boolean isActive;
    @JsonProperty("mentionUserId")
    private String mentionUserId;
    @JsonProperty("articleId")
    private String articleId;
    @JsonProperty("userName")
    private String userName;
    @JsonProperty("user")
    private RegistrationData user;
    @JsonProperty("eventType")
    private String eventType;
    @JsonProperty("mentions")
    private List<String> mentions;
    @JsonProperty("replyArticleList")
    private ReplyArticles replyArticles;
    @JsonProperty("favouriteArticles")
    private FavouriteArticles favouriteArticles;
    /**
     * No args constructor for use in serialization
     * 
     */
    public ArticleStatusResponseDB() {
    	//Default constructor
    }

    public ArticleStatusResponseDB(ArticleStatusResponse response) {
    	this.authorId = response.getAuthor_id();
    	this.authorProfileUrl = response.getAuthor_profile_url();
    	this.authorUserName = response.getAuthor_user_name();
    	this.createdAt = response.getCreated_at();
    	this.eventType = response.getEvent_type();
    	this.favouriteArticles = response.getFavourite_articles();
    	this.id = response.getId();
    	this.isActive = response.isActive();
    	this.mentions = response.getMentions();
    	this.mentionUserId = response.getMention_user_id();
    	this.replyArticles = response.getReply_articles();
    	this.text = response.getText();
    	this.articleId = response.getArticle_id();
    	this.articleType = response.getArticle_type();
    	this.updatedAt = response.getUpdated_at();
    	this.user = response.getUser();
    	this.userIdMention = response.getUser_id_mention();
    	this.userName = response.getUser_name();
    }

	


	/**
	 * @return the createdAt
	 */
	@JsonProperty("createdAt")
	public String getCreatedAt() {
		return createdAt;
	}





	/**
	 * @param createdAt the createdAt to set
	 */
	@JsonProperty("createdAt")
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}





	/**
	 * @return the authorId
	 */
	@JsonProperty("authorId")
	public String getAuthorId() {
		return authorId;
	}





	/**
	 * @param authorId the authorId to set
	 */
	@JsonProperty("authorId")
	public void setAuthorId(String authorId) {
		this.authorId = authorId;
	}





	/**
	 * @return the text
	 */
	@JsonProperty("text")
	public String getText() {
		return text;
	}





	/**
	 * @param text the text to set
	 */
	@JsonProperty("text")
	public void setText(String text) {
		this.text = text;
	}





	/**
	 * @return the userIdMention
	 */
	@JsonProperty("userIdMention")
	public String getUserIdMention() {
		return userIdMention;
	}





	/**
	 * @param userIdMention the userIdMention to set
	 */
	@JsonProperty("userIdMention")
	public void setUserIdMention(String userIdMention) {
		this.userIdMention = userIdMention;
	}





	/**
	 * @return the authorUserName
	 */
	@JsonProperty("authorUserName")
	public String getAuthorUserName() {
		return authorUserName;
	}





	/**
	 * @param authorUserName the authorUserName to set
	 */
	@JsonProperty("authorUserName")
	public void setAuthorUserName(String authorUserName) {
		this.authorUserName = authorUserName;
	}





	/**
	 * @return the authorProfileUrl
	 */
	@JsonProperty("authorProfileUrl")
	public String getAuthorProfileUrl() {
		return authorProfileUrl;
	}





	/**
	 * @param authorProfileUrl the authorProfileUrl to set
	 */
	@JsonProperty("authorProfileUrl")
	public void setAuthorProfileUrl(String authorProfileUrl) {
		this.authorProfileUrl = authorProfileUrl;
	}





	/**
	 * @return the articleType
	 */
	@JsonProperty("articleType")
	public String getArticleType() {
		return articleType;
	}





	/**
	 * @param articleType the articleType to set
	 */
	@JsonProperty("articleType")
	public void setArticleType(String articleType) {
		this.articleType = articleType;
	}





	/**
	 * @return the updatedAt
	 */
	@JsonProperty("updatedAt")
	public String getUpdatedAt() {
		return updatedAt;
	}





	/**
	 * @param updatedAt the updatedAt to set
	 */
	@JsonProperty("updatedAt")
	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}





	/**
	 * @return the isActive
	 */
	@JsonProperty("isActive")
	public boolean isActive() {
		return isActive;
	}





	/**
	 * @param isActive the isActive to set
	 */
	@JsonProperty("isActive")
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}





	/**
	 * @return the mentionUserId
	 */
	@JsonProperty("mentionUserId")
	public String getMentionUserId() {
		return mentionUserId;
	}





	/**
	 * @param mentionUserId the mentionUserId to set
	 */
	@JsonProperty("mentionUserId")
	public void setMentionUserId(String mentionUserId) {
		this.mentionUserId = mentionUserId;
	}





	/**
	 * @return the id
	 */
	@JsonProperty("id")
	public String getId() {
		return id;
	}





	/**
	 * @param id the id to set
	 */
	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}





	/**
	 * @return the articleId
	 */
	@JsonProperty("articleId")
	public String getArticleId() {
		return articleId;
	}





	/**
	 * @param articleId the articleId to set
	 */
	@JsonProperty("articleId")
	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}





	/**
	 * @return the userName
	 */
	@JsonProperty("userName")
	public String getUserName() {
		return userName;
	}





	/**
	 * @param userName the userName to set
	 */
	@JsonProperty("userName")
	public void setUserName(String userName) {
		this.userName = userName;
	}





	/**
	 * @return the user
	 */
	@JsonProperty("user")
	public RegistrationData getUser() {
		return user;
	}





	/**
	 * @param user the user to set
	 */
	@JsonProperty("user")
	public void setUser(RegistrationData user) {
		this.user = user;
	}

	/**
	 * @return the eventType
	 */
	@JsonProperty("eventType")
	public String getEventType() {
		return eventType;
	}

	/**
	 * @param eventType the eventType to set
	 */
	@JsonProperty("eventType")
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	



	/**
	 * @return the mentions
	 */
	@JsonProperty("mentions")
	public List<String> getMentions() {
		return mentions;
	}






	/**
	 * @param mentions the mentions to set
	 */
	@JsonProperty("mentions")
	public void setMentions(List<String> mentions) {
		this.mentions = mentions;
	}






	/**
	 * @return the replyArticles
	 */
	@JsonProperty("replyArticleList")
	public ReplyArticles getReplyArticles() {
		return replyArticles;
	}





	/**
	 * @param replyArticles the replyArticles to set
	 */
	@JsonProperty("replyArticleList")
	public void setReplyArticles(ReplyArticles replyArticles) {
		this.replyArticles = replyArticles;
	}





	/**
	 * @return the favouriteArticles
	 */
	@JsonProperty("favouriteArticles")
	public FavouriteArticles getFavouriteArticles() {
		return favouriteArticles;
	}





	/**
	 * @param favouriteArticles the favouriteArticles to set
	 */
	@JsonProperty("favouriteArticles")
	public void setFavouriteArticles(FavouriteArticles favouriteArticles) {
		this.favouriteArticles = favouriteArticles;
	}

	
	

}
