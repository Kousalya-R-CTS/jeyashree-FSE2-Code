package com.socio.articleManagement.webservices;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.socio.articleManagement.models.*;
import com.socio.articleManagement.util.SocioAppConstants;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.socio.articleManagement.exception.BaseClassException;
import com.socio.articleManagement.models.ArticleStatusResponseDB;
import com.socio.articleManagement.repository.ArticleOperationRepository;
import com.socio.articleManagement.service.IArticleService;

/**
 * @author User
 *
 */
@RestController
@EnableAutoConfiguration
@CrossOrigin(origins = "*")
public class ArticleController {
	/**
	 * logger for logging data
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ArticleController.class);
	@Autowired
	private ArticleOperationRepository articleOperationRepository;
	/**
	 * holds articleService reference
	 */
	@Autowired
	private IArticleService articleService;

	/**
	 * default constructor
	 */
	public ArticleController() {
		super();
	}
	
	/**
	 * @param articleService the articleService to set
	 */
	public void setArticleService(IArticleService articleService) {
		this.articleService = articleService;
	}


	/**
	 * method saveArticles - to create articles
	 * 
	 * @param userName              - userName
	 * @param articleStatusResponse - articleStatusResponse
	 * @param httpServletResponse   - httpServletResponse
	 * @return response - response
	 * @throws BaseClassException - exception
	 */
	@RequestMapping(value = "/{userName}/add", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseGateway> saveArticles(@PathVariable String userName,
                                                        @RequestBody ArticleStatusResponse articleStatusResponse, HttpServletResponse httpServletResponse)
			throws BaseClassException {
		LOGGER.info("saveArticles() api is invoked");
		ResponseGateway gateway = new ResponseGateway();
		ResponseEntity<ResponseGateway> responseGateway = null;
		try {
			articleStatusResponse = articleService.saveArticles(articleStatusResponse);
			responseGateway = gateway.buildResponse(articleStatusResponse, "", "201");
		} catch (Exception e) {
			// Exception handling
			LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("Exit: saveArticles()");
		return responseGateway;
	}
	/**
	 * method updateArticles - to update articles
	 * 
	 * @param userName              - userName
	 * @param articleStatusResponse - articleStatusResponse
	 * @param httpServletResponse   - httpServletResponse
	 * @return response - response
	 * @throws BaseClassException - exception
	 */
	@RequestMapping(value = "/{userName}/update/{id}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseGateway> updateArticles(@PathVariable String userName, @PathVariable String id,
														  @RequestBody ArticleStatusResponse articleStatusResponse, HttpServletResponse httpServletResponse)
			throws BaseClassException {
		LOGGER.info("updateArticles() api is invoked");
		ResponseGateway gateway = new ResponseGateway();
		ResponseEntity<ResponseGateway> responseGateway = null;
		try {
			articleStatusResponse = articleService.updateArticles(articleStatusResponse);
			responseGateway = gateway.buildResponse(articleStatusResponse, "", "201");
		} catch (Exception e) {
			// Exception handling
			LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("Exit: updateArticles()");
		return responseGateway;
	}
	/**
	 * method updateArticles - to update artciles
	 * 
	 * @param userName              - userName
	 * @param articleStatusResponse - articleStatusResponse
	 * @param httpServletResponse   - httpServletResponse
	 * @return response - response
	 * @throws BaseClassException - exception
	 */
	@RequestMapping(value = "/{userName}/like/{id}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseGateway> favouriteArticles(@PathVariable String userName, @PathVariable String id,
															 @RequestBody ArticleStatusResponse articleStatusResponse, HttpServletResponse httpServletResponse)
			throws BaseClassException {
		LOGGER.info("favouriteArticles() api is invoked");
		ResponseGateway gateway = new ResponseGateway();
		ResponseEntity<ResponseGateway> responseGateway = null;
		try {
			articleStatusResponse = articleService.favouriteArticles(articleStatusResponse , userName);
			responseGateway = gateway.buildResponse(articleStatusResponse, "", "201");
		} catch (Exception e) {
			// Exception handling
			LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("Exit: favouriteArticles()");
		return responseGateway;
	}
	/**
	 * method replyArticles - to reply articles
	 * 
	 * @param userName              - userName
	 * @param articleStatusResponse - articleStatusResponse
	 * @param httpServletResponse   - httpServletResponse
	 * @return response - response
	 * @throws BaseClassException - exception
	 */
	@RequestMapping(value = "/{userName}/reply/{id}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseGateway> replyArticles(@PathVariable String userName, @PathVariable String id,
														 @RequestBody ArticleStatusResponse articleStatusResponse, HttpServletResponse httpServletResponse)
			throws BaseClassException {
		LOGGER.info("replyArticles() api is invoked");
		ResponseGateway gateway = new ResponseGateway();
		ResponseEntity<ResponseGateway> responseGateway = null;
		try {
			articleStatusResponse = articleService.replyArticles(articleStatusResponse);
			responseGateway = gateway.buildResponse(articleStatusResponse, "", "201");
		} catch (Exception e) {
			// Exception handling
			LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("Exit: replyArticles()");
		return responseGateway;
	}
	/**
	 * method searchAllArticles - to search all articles
	 * @param httpServletResponse - response
	 * @return ResponseEntity - entity
	 * @throws BaseClassException - exception
	 */
	@RequestMapping(value="/all", method= RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseGateway> searchAllArticles(

			HttpServletResponse httpServletResponse) throws BaseClassException
	{
		LOGGER.info("searchAllArticles() api is invoked");
		ResponseGateway gateway = new ResponseGateway();
		ResponseEntity<ResponseGateway> responseGateway = null;
		ArticleStatusResponses resp = new ArticleStatusResponses();
		List<ArticleStatusResponseDB> articles = new ArrayList<ArticleStatusResponseDB>();
		try
		{
			articles = articleOperationRepository.findAll(Sort.by(Sort.Direction.DESC, "createdAt").and(Sort.by(Sort.Direction.DESC, "updatedAt")));
			setMetaData(resp, articles);
			responseGateway = gateway.buildResponse(resp, "", "200");
		}	
		catch(Exception e)
		{
		 //Exception handling
		 LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("Exit: searchAllArticles()");
		return responseGateway;
	}

	/**method setMetaData
	 * @param resp - resp
	 * @param articles - articles
	 */
	public void setMetaData(ArticleStatusResponses resp, List<ArticleStatusResponseDB> articles) {
		MetaData metaData = new MetaData();
		metaData.setOffset(0);
		metaData.setResultCount(articles.size());
		metaData.setTotalCount(articles.size());
		resp.setMetaData(metaData);
		resp.setArticles(articles);
	}
	/**
	 * method searchAllArticles - to search all articles
	 * @param name - name
	 * @param httpServletResponse - response
	 * @return ResponseEntity - entity
	 * @throws BaseClassException - exception
	 */
	@RequestMapping(value="/username", method= RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseGateway> getUserArticles(
			@RequestParam(value="id", required=false) String id, @RequestParam (value="name", required=false) String name,
			@RequestParam(value="threadId", required =false) String threadId,
			HttpServletResponse httpServletResponse) throws BaseClassException
	{
		LOGGER.info("getUserArticles() api is invoked");
		ResponseGateway gateway = new ResponseGateway();
		ResponseEntity<ResponseGateway> responseGateway = null;
		ArticleStatusResponses resp = new ArticleStatusResponses();
		List<ArticleStatusResponseDB> articles = null;
		try
		{
			articles = articleService.getUserArticles(id, name, threadId);
			setMetaData(resp, articles);
			responseGateway = gateway.buildResponse(resp, "", "200");
		}	
		catch(Exception e)
		{
		 //Exception handling
		 LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("Exit: getUserArticles()");
		return responseGateway;
	}
	/**
	 * method deleteArticle - to deleteArticle
	 * @param username - name
	 * @param httpServletResponse - response
	 * @return ResponseEntity - entity
	 * @throws BaseClassException - exception
	 */
	@RequestMapping(value="/{username}/delete/{id}", method= RequestMethod.DELETE, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseGateway> deleteArticle(
			@PathVariable String username, @PathVariable String id,
			HttpServletResponse httpServletResponse) throws BaseClassException
	{
		LOGGER.info("deleteArticle() api is invoked");
		ResponseGateway gateway = new ResponseGateway();
		ResponseEntity<ResponseGateway> responseGateway = null;
		List<String> error = new ArrayList<>();
		boolean result = false;
		try
		{

			result = articleService.deleteArticle(id, username);
		
		if(result)
		{
			responseGateway = gateway.buildResponse("", "", "204");
		}
		else
		{
			error.add("No record found");
			responseGateway = gateway.buildResponse(error, "", "404");
		}
		}	
		catch(Exception e)
		{
		 //Exception handling
		 LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("Exit: deleteArticle()");
		return responseGateway;
	}
}
