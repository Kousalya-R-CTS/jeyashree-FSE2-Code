package com.socio.articleManagement.models;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"totalCount", "resultCount", "offset"})
public class MetaData {

    @JsonProperty("totalCount")
    private Integer totalCount;
    @JsonProperty("resultCount")
    private Integer resultCount;
    @JsonProperty("offset")
    private Integer offset;

    /**
     * No args constructor for use in serialization
     * 
     */
    public MetaData() 
    {
    	//constructor
    }
	/**
	 * @return the totalCount
	 */
	@JsonProperty("totalCount")
	public Integer getTotalCount() {
		return totalCount;
	}
	/**
	 * @param totalCount the totalCount to set
	 */
	@JsonProperty("totalCount")
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
	/**
	 * @return the resultCount
	 */
	@JsonProperty("resultCount")
	public Integer getResultCount() {
		return resultCount;
	}
	/**
	 * @param resultCount the resultCount to set
	 */
	@JsonProperty("resultCount")
	public void setResultCount(Integer resultCount) {
		this.resultCount = resultCount;
	}
	/**
	 * @return the offset
	 */
	@JsonProperty("offset")
	public Integer getOffset() {
		return offset;
	}
	/**
	 * @param offset the offset to set
	 */
	@JsonProperty("offset")
	public void setOffset(Integer offset) {
		this.offset = offset;
	}

   

}
