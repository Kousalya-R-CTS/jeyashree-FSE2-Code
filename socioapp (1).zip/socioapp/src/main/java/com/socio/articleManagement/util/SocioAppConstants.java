package com.socio.articleManagement.util;

/**
 * class SocioAppConstants
 *
 */
public final class SocioAppConstants
{
	
	/**
	 * HTTPSTATUS_BAD_REQUEST
	 */
	public static final int HTTPSTATUS_BAD_REQUEST = 400;
	/**
	 * HTTPSTATUS_OK
	 */
	public static final int HTTPSTATUS_OK = 200;
	/**
	 * HTTPSTATUS_NOT_FOUND
	 */
	public static final int HTTPSTATUS_NOT_FOUND = 404;
	/**
	 * HTTPSTATUS_UN_AUTHORIZED
	 */
	public static final int HTTPSTATUS_UN_AUTHORIZED = 401;
	/**
	 * INTERNAL_SERVER_ERROR
	 */
	public static final int INTERNAL_SERVER_ERROR = 500;
	/**
	 * NEW
	 */
	public static final String NEW = "NEW";
	/**
	 * UNLIKE
	 */
	public static final String UNLIKE = "UNLIKE";
	/**
	 * UPDATE
	 */
	public static final String UPDATE = "UPDATE";
	/**
	 * REPLY
	 */
	public static final String REPLY = "REPLY";
	/**
	 * LIKE
	 */
	public static final String LIKE = "LIKE";
	/**
	 * NUM1
	 */
	public static final int NUM1 = 1;
	/**
	 * DISLIKE 
	 */
	public static final String DISLIKE = "DISLIKE";
	/**
	 * ORIGINAL
	 */
	public static final String ORIGINAL = "ORIGINAL";
	/**
	 * ERROR_DETAILS
	 */
	public static final String ERROR_DETAILS = "Error details";
	/**
	 * API_ERROR
	 */
	public static final String API_ERROR = "API_ERROR {}";
	
	/**
	 * constructor
	 */
	private SocioAppConstants() {
		// default constructor
	}
}
