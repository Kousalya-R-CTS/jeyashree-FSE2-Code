package com.socio.articleManagement.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.socio.articleManagement.models.*;
import com.socio.articleManagement.service.IArticleService;
import com.socio.articleManagement.util.SocioAppConstants;
import com.socio.articleManagement.util.SocioAppServiceUtil;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.socio.articleManagement.exception.BaseClassException;
import com.socio.articleManagement.models.FavouriteArticles;
import com.socio.articleManagement.repository.ArticleOperationRepository;
import com.socio.articleManagement.repository.ArticleRepository;
import com.socio.articleManagement.repository.UserOperationRepository;

/**
 * class ArticleServiceImpl implements IArticleService
 *
 */
@Service
public class ArticleServiceImpl implements IArticleService
{

	/**
	 * logger for logging data
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ArticleServiceImpl.class);
	
	/**
	 * holds userRepository reference
	 */
	@Autowired
	private ArticleRepository articleRepository;
	/**
	 * holds articleOperationRepository reference
	 */
	@Autowired
	private ArticleOperationRepository articleOperationRepository;
	/**
	 * holds userOperationRepository reference
	 */
	@Autowired
	private UserOperationRepository userOperationRepository;

	@Autowired
    ObjectMapper objectMapper;
	/**
	 * default constructor
	 */
	public ArticleServiceImpl() {
		super();
	}
	/**
	 * method saveArticles - to create articles
	 * @param articleStatusResponse - articleStatusResponse
	 * @return TwitterStatusResponse - TwitterStatusResponse
	 * @throws BaseClassException - exception
	 */
	@Override
	public ArticleStatusResponse saveArticles(ArticleStatusResponse articleStatusResponse) throws ParseException, BaseClassException
	{
		ArticleStatusResponseDB response = new ArticleStatusResponseDB(articleStatusResponse);
		if(SocioAppConstants.NEW.equalsIgnoreCase(articleStatusResponse.getEvent_type()))
		{

			List<String> userName = new ArrayList<>();
			userOperationRepository.findAll().forEach((RegistrationData data) ->
			{
				if(articleStatusResponse.getText().contains(data.getLoginId()))
				userName.add(data.getLoginId());
				});
			//To get mention user name from article which user created and linked with the user
			response.setMentions(userName);
			response.setArticleId(SocioAppServiceUtil.getNonce());
			response.setCreatedAt(SocioAppServiceUtil.getCurrentDate());
			response.setUpdatedAt(SocioAppServiceUtil.getCurrentDate());
		}
		processArticles(response);
		return articleStatusResponse;
	}

	    /**
	     * method processArticles - to save data in mongoDB
	     * @throws JsonProcessingException - exception
	     */
	    public void processArticles(ArticleStatusResponseDB response)  {

	    	LOGGER.info("processArticles : {} ", response);
	    	//check if event type is 'NEW' for adding articles or event type is 'UPDATE' for delete, reply, likes operation
	        switch(response.getEventType()){

	            case SocioAppConstants.NEW:
	            {
	            	saveResponse(response);
	                break;
	            }
	            case SocioAppConstants.UPDATE:
	            {
	                //validate the articles
	                validate(response);
	                saveResponse(response);
	                break;
	            }
	            case SocioAppConstants.LIKE:
	            {
	                //validate the articles
	                validate(response);
	                saveResponse(response);
	                break;
	            }
	            case SocioAppConstants.DISLIKE:
	            {
	                //validate the articles
	                validate(response);
	                saveResponse(response);
	                break;
	            }
	            default:
	                LOGGER.info("Invalid Event Type");
	        }
	    }
		/**
		 * method saveResponse - save in mongoDB
		 * @param response - response
		 */
		public void saveResponse(ArticleStatusResponseDB response) {
			articleOperationRepository.save(response);
			LOGGER.info("Successfully Persisted the libary Event {} ", response);
		}

	    private void validate(ArticleStatusResponseDB twitterStatusResponse) {
	    	Optional<ArticleStatusResponseDB> statusOptional = articleOperationRepository.findById(twitterStatusResponse.getId());
	        if(!statusOptional.isPresent()){
	            throw new IllegalArgumentException("Not a valid Event");
	        }
	        LOGGER.info("Validation is successful for the Event : {} ", statusOptional.get());

	    }
	    /**
		 * method deleteArticle - to delete articles from DB
		 * @param id - id 
		 * @return boolean - result
		 * @throws BaseClassException - exception
		 */
		@Override
		public boolean deleteArticle(String id, String name) throws BaseClassException
		{
			return articleRepository.deleteArticle(id, name);
		}
		 /**
		 * method getUserArticles - to get user articles from DB
		 * @param id - id 
		 * @param name - name
		 * @return List<ArticleStatusResponse>  - list
		 * @throws BaseClassException - exception
		 */
		@Override
		public List<ArticleStatusResponseDB> getUserArticles(String id, String name, String threadId) throws BaseClassException
		{
			return articleRepository.getUserArticles(id, name, threadId);
		}
		/**
		 * method updateArticles - to update articles
		 * @param twitterStatusResponse - twitterStatusResponse 
		 * @return ArticleStatusResponse - ArticleStatusResponse
		 * @throws BaseClassException - exception
		 */
		@Override
		public ArticleStatusResponse updateArticles(ArticleStatusResponse twitterStatusResponse) throws BaseClassException
		{
			try
			{
				ArticleStatusResponseDB response = new ArticleStatusResponseDB(twitterStatusResponse);
				response.setUpdatedAt(SocioAppServiceUtil.getCurrentDate());
				processArticles(response);
			}
			catch (ParseException e) {
				// Exception handling
				LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
				
			}
			return twitterStatusResponse;
		}
		/**
		 * method replyArticles - to reply articles
		 * @param twitterStatusResponse - twitterStatusResponse 
		 * @return ArticleStatusResponse - ArticleStatusResponse
		 * @throws BaseClassException - exception
		 */
		@Override
		public ArticleStatusResponse replyArticles(ArticleStatusResponse twitterStatusResponse) throws BaseClassException
		{
			try
			{
					/**
					 * If operation is update means then it will be reply, delete, favourite, update
					 * For articles type - REPLY && event Type - UPDATE
					 * 	1. save as a new article with generated ID and append user details to article from DB
					 * 	2. append Reply Article to Original Article  which contains Reply Articles List
					 * For eventType - LIKE && whatever the articleType
					 * 	1. get article object from DB and update favourite count in favourite object of every article holds
					 * 	
					 */
					twitterStatusResponse.setUpdated_at(SocioAppServiceUtil.getCurrentDate());
					ArticleStatusResponseDB statusResponse = articleOperationRepository.searchArticleById(twitterStatusResponse.getArticle_id());
					if(SocioAppConstants.REPLY.equalsIgnoreCase(twitterStatusResponse.getArticle_type()) &&
							SocioAppConstants.UPDATE.equalsIgnoreCase(twitterStatusResponse.getEvent_type()))
					{
						ArticleStatusResponseDB articleReply = new ArticleStatusResponseDB();
				       
		        		articleReply.setAuthorId(twitterStatusResponse.getAuthor_id());
		        		articleReply.setAuthorProfileUrl(twitterStatusResponse.getAuthor_profile_url());
		        		articleReply.setAuthorUserName(twitterStatusResponse.getAuthor_user_name());
		        		articleReply.setEventType(twitterStatusResponse.getEvent_type());
		        		articleReply.setMentionUserId(twitterStatusResponse.getMention_user_id());
		        		articleReply.setUserName(twitterStatusResponse.getUser_name());
		        		articleReply.setText(twitterStatusResponse.getText());
		        		articleReply.setActive(true);
		        		articleReply.setCreatedAt(twitterStatusResponse.getUpdated_at());
		        		articleReply.setArticleType(twitterStatusResponse.getArticle_type());
		        		//save reply as a new article so id is generated
		        		articleReply.setId(new ObjectId().toHexString());
		        		articleReply.setArticleId(SocioAppServiceUtil.getNonce());
		        		//Set User Details in Reply article
		        		articleReply.setUser(userOperationRepository.searchUserByEmail(
		        				twitterStatusResponse.getAuthor_user_name()).get(0));
		        		//Save as new article
		        		saveResponse(articleReply);
		        		 //Data from user for reply
		        		ReplyArticle replyArticle = new ReplyArticle();
		        		replyArticle.setOriginalArticleId(twitterStatusResponse.getArticle_id());
		        		replyArticle.setReplyAt(twitterStatusResponse.getUpdated_at());
		        		replyArticle.setReplyUserName(twitterStatusResponse.getAuthor_user_name());
		        		replyArticle.setThreadId(articleReply.getArticleId());
			        	//Check if article has already reply
			        	if(null != statusResponse.getReplyArticles() &&
								null != statusResponse.getReplyArticles().getReplyArticleList()
						&& !statusResponse.getReplyArticles().getReplyArticleList().isEmpty() && statusResponse.getReplyArticles().getReplyCount() > 0)
			        	{
			        		//System.out.println(statusResponse.getReplyArticles());
			        		//Get List of reply for that article.
			        		ReplyArticles replyArticles = statusResponse.getReplyArticles();
			        		List<ReplyArticle> replyArticleList = replyArticles.getReplyArticleList();
			        		//Set Count update
			        		replyArticles.setReplyCount(replyArticles.getReplyCount() + SocioAppConstants.NUM1);
			        		//Append Reply to chain of reply
			        		replyArticleList.add(replyArticle);
			        		replyArticles.setReplyArticleList(replyArticleList);
			        		statusResponse.setReplyArticles(replyArticles);
			        	}
			        	else
			        	{
			        		ReplyArticles replyArticles = new ReplyArticles();
			        		replyArticles.setReplyCount(SocioAppConstants.NUM1);
							replyArticles.setThreadId(articleReply.getArticleId());
			        		List<ReplyArticle> replyList = new ArrayList<>();
			        		replyList.add(replyArticle);
			        		replyArticles.setReplyArticleList(replyList);
			        		statusResponse.setReplyArticles(replyArticles);
			        	} 
					}
					
					processArticles(statusResponse);
			}
			catch (ParseException e) {
				// Exception handling
				LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
				
			}
			return twitterStatusResponse;
		}
		/**
		 * method updateArticles - to update articles
		 * @param articleStatusResponse - articleStatusResponse
		 * @return ArticleStatusResponse - ArticleStatusResponse
		 * @throws BaseClassException - exception
		 */
		@Override
		public ArticleStatusResponse favouriteArticles(ArticleStatusResponse articleStatusResponse, String authorUserName) throws BaseClassException
		{
			try
			{
				
				ArticleStatusResponseDB statusResponse = articleOperationRepository.searchArticleById(articleStatusResponse.getArticle_id());
				if(SocioAppConstants.LIKE.equalsIgnoreCase(articleStatusResponse.getEvent_type()))
				{
					FavouriteArticle favouriteArticle = new FavouriteArticle();
					favouriteArticle.setCreatedAt(SocioAppServiceUtil.getCurrentDate());
					favouriteArticle.setFavouriteAt(SocioAppServiceUtil.getCurrentDate());
					favouriteArticle.setFavouriteUserName(authorUserName);
					favouriteArticle.setLike(true);
					favouriteArticle.setArticleId(articleStatusResponse.getArticle_id());
					FavouriteArticles favouriteArticlesDb = statusResponse.getFavouriteArticles();
					if(null != favouriteArticlesDb)
					{
						favouriteArticlesDb.setFavouriteCount(favouriteArticlesDb.getFavouriteCount() + SocioAppConstants.NUM1);
						List<FavouriteArticle> favouriteList = favouriteArticlesDb.getFavouriteArticleList();
						favouriteList.add(favouriteArticle);
						favouriteArticlesDb.setFavouriteArticleList(favouriteList);
						statusResponse.setFavouriteArticles(favouriteArticlesDb);
					}
					else
					{	
						FavouriteArticles favouriteArticles = new FavouriteArticles();
						favouriteArticles.setFavouriteCount(SocioAppConstants.NUM1);
						List<FavouriteArticle> favouriteArticleList = new ArrayList<FavouriteArticle>();
						favouriteArticleList.add(favouriteArticle);
						favouriteArticles.setFavouriteArticleList(favouriteArticleList);
						statusResponse.setFavouriteArticles(favouriteArticles);
						LOGGER.info("OBJECT {}", statusResponse);
					}
				}
				
				processArticles(statusResponse);
			}
			catch (ParseException e) {
				// Exception handling
				LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
				
			}
			return articleStatusResponse;
		}
		
		

}
