package com.socio.articleManagement.repository;

import com.socio.articleManagement.models.ArticleStatusResponseDB;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * class ArticleOperationRepositorFy
 *
 */
@Repository
public interface ArticleOperationRepository extends MongoRepository<ArticleStatusResponseDB, String>
{
	@Query("{'articleId': {'$eq':?0 }}")
    ArticleStatusResponseDB searchArticleById(String articleId);
}
