package com.socio.articleManagement.repository;

import com.socio.articleManagement.util.SocioAppConstants;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.socio.articleManagement.exception.BaseClassException;
import com.socio.articleManagement.models.Registration;
import com.socio.articleManagement.models.RegistrationData;

/**
 * class UserRepository
 *
 */
@Repository
public class UserRepository
{
	
	@Autowired
	private MongoTemplate mongoTemplate;
	/**
	 * logger for logging data
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(UserRepository.class);
	
	/**
	 * default constructor
	 */
	public UserRepository() {
		super();
	}
	/**
	 * method saveUser method - to save user details on MongoDB
	 * 
	 */
	public RegistrationData saveUser(Registration registration) throws BaseClassException
	{
		LOGGER.info("saveUser() api is invoked");
		RegistrationData response = null;
		registration.setStatus("active");
		try
		{
			
			response = mongoTemplate.save(new RegistrationData(registration), "user_detail");
		}
		catch(Exception e)
		{
		 //Exception handling
		 LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("Exit : saveUser() api");
		return response;
	}
	/**
	 * method saveUser method - to save user details on MongoDB
	 * 
	 */
	public RegistrationData updateUser(Registration registration) throws BaseClassException
	{
		LOGGER.info("updateUser() api is invoked");
		RegistrationData registrationData = null;
		try
		{
			Query query = new Query();
			query.addCriteria(Criteria.where("email").is(registration.getEmail()));
			Update update = new Update();
			update.set("password", registration.getPassword());
			registrationData = mongoTemplate.findAndModify(query, update, 
					new FindAndModifyOptions().returnNew(true), RegistrationData.class);
		}
		catch(Exception e)
		{
		 //Exception handling
		 LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("Exit : updateUser() api");
		return registrationData;
	}
	/**
	 * method saveUser method - to save user details on MongoDB
	 * 
	 */
	public RegistrationData getLoginStatus(String name, String password) throws BaseClassException
	{
		LOGGER.info("updateUser() api is invoked");
		RegistrationData data = null;
		try
		{
			Query query = new Query();
			query.addCriteria(Criteria.where("loginId").is(name).and("password").is(password));
			data = mongoTemplate.findOne(query, RegistrationData.class);
		}
		catch(Exception e)
		{
		 //Exception handling
		 LOGGER.error(SocioAppConstants.API_ERROR, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("Exit : updateUser() api");
		return data;
	}
	

}
