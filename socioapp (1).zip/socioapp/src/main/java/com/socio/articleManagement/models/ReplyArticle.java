
package com.socio.articleManagement.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReplyArticle {

    @JsonProperty("threadId")
    private String threadId;
    @JsonProperty("replyUserName")
    private String replyUserName;
    @JsonProperty("originalArticleId")
    private String originalArticleId;
    @JsonProperty("replyAt")
    private String replyAt;
    @JsonProperty("articleId")
    private String articleId;
    
    /**
     * No args constructor for use in serialization
     * 
     */
    public ReplyArticle() {
    }

	public ReplyArticle(String threadId, String replyUserName, String originalArticleId, String replyAt, String articleId) {
		super();
		this.threadId = threadId;
		this.replyUserName = replyUserName;
		this.originalArticleId = originalArticleId;
		this.replyAt = replyAt;
		this.articleId = articleId;
		
	}

	/**
	 * @return the threadId
	 */
	@JsonProperty("threadId")
	public String getThreadId() {
		return threadId;
	}

	/**
	 * @param threadId the threadId to set
	 */
	@JsonProperty("threadId")
	public void setThreadId(String threadId) {
		this.threadId = threadId;
	}

	/**
	 * @return the replyUserName
	 */
	@JsonProperty("replyUserName")
	public String getReplyUserName() {
		return replyUserName;
	}

	/**
	 * @param replyUserName the replyUserName to set
	 */
	@JsonProperty("replyUserName")
	public void setReplyUserName(String replyUserName) {
		this.replyUserName = replyUserName;
	}

	/**
	 * @return the originalArticleId
	 */
	@JsonProperty("originalArticleId")
	public String getOriginalArticleId() {
		return originalArticleId;
	}

	/**
	 * @param originalArticleId the originalArticleId to set
	 */
	@JsonProperty("originalArticleId")
	public void setOriginalArticleId(String originalArticleId) {
		this.originalArticleId = originalArticleId;
	}

	/**
	 * @return the replyAt
	 */
	@JsonProperty("replyAt")
	public String getReplyAt() {
		return replyAt;
	}

	/**
	 * @param replyAt the replyAt to set
	 */
	@JsonProperty("replyAt")
	public void setReplyAt(String replyAt) {
		this.replyAt = replyAt;
	}

	/**
	 * @return the articleId
	 */
	@JsonProperty("articleId")
	public String getArticleId() {
		return articleId;
	}

	/**
	 * @param articleId the articleId to set
	 */
	@JsonProperty("articleId")
	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}

	


}
