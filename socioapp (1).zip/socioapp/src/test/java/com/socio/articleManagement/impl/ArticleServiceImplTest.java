package com.socio.articleManagement.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import com.socio.articleManagement.models.*;
import com.socio.articleManagement.repository.ArticleOperationRepository;
import com.socio.articleManagement.util.SocioAppConstants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.socio.articleManagement.exception.BaseClassException;
import com.socio.articleManagement.models.ReplyArticle;
import com.socio.articleManagement.repository.ArticleRepository;
import com.socio.articleManagement.repository.UserOperationRepository;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ArticleServiceImplTest {
	/**
	 * holds userRepository reference
	 */
	@Mock
	private ArticleRepository articleRepository;
	/**
	 * holds articleOperationRepository reference
	 */
	@Mock
	private ArticleOperationRepository articleOperationRepository;
	/**
	 * holds userOperationRepository reference
	 */
	@Mock
	private UserOperationRepository userOperationRepository;
	@Mock
    ObjectMapper objectMapper;
	@InjectMocks
	private ArticleServiceImpl tweetServiceImpl;
	
	
	
	@Test
	public void saveTweetTest() throws BaseClassException, ParseException
	{
		ArticleStatusResponse twitterStatusResponse = new ArticleStatusResponse();
		twitterStatusResponse.setEvent_type("NEW");
		twitterStatusResponse.setText("ALL");
		Mockito.when(userOperationRepository.findAll()).thenReturn(new ArrayList<RegistrationData>());
		assertNotNull(tweetServiceImpl.saveArticles(twitterStatusResponse));
	}
	@Test
	public void saveTweetTestMentions() throws BaseClassException, ParseException
	{
		ArticleStatusResponse twitterStatusResponse = new ArticleStatusResponse();
		twitterStatusResponse.setEvent_type("NEW");
		twitterStatusResponse.setText("ALL");
		List<RegistrationData> registrationlist = new ArrayList<RegistrationData>();
		RegistrationData data = new RegistrationData();
		data.setLoginId("ALL");
		registrationlist.add(data);
		Mockito.when(userOperationRepository.findAll()).thenReturn(registrationlist);
		assertNotNull(tweetServiceImpl.saveArticles(twitterStatusResponse));
	}
	public void saveTweetTestMentionsNotThere() throws BaseClassException, ParseException
	{
		ArticleStatusResponse twitterStatusResponse = new ArticleStatusResponse();
		twitterStatusResponse.setEvent_type("NEW");
		twitterStatusResponse.setText("ALL");
		List<RegistrationData> registrationlist = new ArrayList<RegistrationData>();
		RegistrationData data = new RegistrationData();
		data.setLoginId("al");
		registrationlist.add(data);
		Mockito.when(userOperationRepository.findAll()).thenReturn(registrationlist);
		assertNotNull(tweetServiceImpl.saveArticles(twitterStatusResponse));
	}
	@Test
	public void saveTweetTestNotNew() throws BaseClassException, ParseException
	{
		ArticleStatusResponse twitterStatusResponse = new ArticleStatusResponse();
		twitterStatusResponse.setEvent_type("OLD");
		twitterStatusResponse.setText("ALL");
		assertNotNull(tweetServiceImpl.saveArticles(twitterStatusResponse));
	}
	@Test
	public void saveTweetTestException() throws BaseClassException, ParseException
	{
		boolean res = false;
		try
		{
			tweetServiceImpl.saveArticles(null);
		}
		catch(Exception e)
		{
			res = true;
		}
		assertTrue(res);
	}
	@Test
	public void deleteTweetTest() throws BaseClassException
	{
		Mockito.when(articleRepository.deleteArticle(null, null)).thenReturn(false);
		assertFalse(tweetServiceImpl.deleteArticle(null, null));
	}
	@Test
	public void getUserTweetsTest() throws BaseClassException
	{
		Mockito.when(articleRepository.getUserArticles(null, null, null)).thenReturn(new
				ArrayList<ArticleStatusResponseDB>());
		assertNotNull(tweetServiceImpl.getUserArticles(null, null,null));
	}
	@Test
	public void updateTweetsTest() throws BaseClassException
	{
		ArticleStatusResponseDB twitterStatusResponse = new ArticleStatusResponseDB();
		ArticleStatusResponse response = new ArticleStatusResponse();
		assertNotNull(tweetServiceImpl.updateArticles(response));
	}
	@Test
	public void replyTweetsTest() throws BaseClassException
	{
		String loginId = "mala";
		List<RegistrationData> registrationlist = new ArrayList<RegistrationData>();
		RegistrationData data = new RegistrationData();
		data.setLoginId(loginId);
		registrationlist.add(data);
		ReplyArticle replyArticle = new ReplyArticle();
		ReplyArticles replyArticles = new ReplyArticles();
		replyArticles.setReplyCount(SocioAppConstants.NUM1);
		List<ReplyArticle> replyList = new ArrayList<>();
		replyList.add(replyArticle);
		replyArticles.setReplyArticleList(replyList);
		ArticleStatusResponseDB db = new ArticleStatusResponseDB();
		db.setReplyArticles(replyArticles);
		ArticleStatusResponse twitterStatusResponse = new ArticleStatusResponse();
		twitterStatusResponse.setReply_articles(null);
		twitterStatusResponse.setAuthor_user_name(loginId);
		twitterStatusResponse.setUser(data);
		twitterStatusResponse.setArticle_type("REPLY");
		twitterStatusResponse.setEvent_type("UPDATE");
		twitterStatusResponse.setArticle_id("a1");
		twitterStatusResponse.setReply_articles(replyArticles);
		Mockito.when(articleOperationRepository.searchArticleById(twitterStatusResponse.getArticle_id())).thenReturn(db);
		Mockito.when(userOperationRepository.searchUserByEmail(loginId)).thenReturn(registrationlist);
		assertNotNull(tweetServiceImpl.replyArticles(twitterStatusResponse));
	}
	@Test
	public void replyTweetsTestEvent() throws BaseClassException
	{
		String loginId = "mala";
		List<RegistrationData> registrationlist = new ArrayList<RegistrationData>();
		RegistrationData data = new RegistrationData();
		data.setLoginId(loginId);
		registrationlist.add(data);
		ReplyArticle replyArticle = new ReplyArticle();
		ReplyArticles replyArticles = new ReplyArticles();
		replyArticles.setReplyCount(SocioAppConstants.NUM1);
		List<ReplyArticle> replyList = new ArrayList<>();
		replyList.add(replyArticle);
		replyArticles.setReplyArticleList(replyList);
		ArticleStatusResponseDB db = new ArticleStatusResponseDB();
		db.setReplyArticles(replyArticles);
		ArticleStatusResponse twitterStatusResponse = new ArticleStatusResponse();
		twitterStatusResponse.setReply_articles(null);
		twitterStatusResponse.setAuthor_user_name(loginId);
		twitterStatusResponse.setUser(data);
		twitterStatusResponse.setArticle_type("REPLY");
		twitterStatusResponse.setEvent_type("fr");
		twitterStatusResponse.setArticle_id("a1");
		twitterStatusResponse.setReply_articles(replyArticles);
		Mockito.when(articleOperationRepository.searchArticleById(twitterStatusResponse.getArticle_id())).thenReturn(db);
		Mockito.when(userOperationRepository.searchUserByEmail(loginId)).thenReturn(registrationlist);
		assertNotNull(tweetServiceImpl.replyArticles(twitterStatusResponse));
	}
	@Test
	public void replyTweetsTestType() throws BaseClassException
	{
		String loginId = "mala";
		List<RegistrationData> registrationlist = new ArrayList<RegistrationData>();
		RegistrationData data = new RegistrationData();
		data.setLoginId(loginId);
		registrationlist.add(data);
		ReplyArticle replyArticle = new ReplyArticle();
		ReplyArticles replyArticles = new ReplyArticles();
		replyArticles.setReplyCount(SocioAppConstants.NUM1);
		List<ReplyArticle> replyList = new ArrayList<>();
		replyList.add(replyArticle);
		replyArticles.setReplyArticleList(replyList);
		ArticleStatusResponseDB db = new ArticleStatusResponseDB();
		db.setReplyArticles(replyArticles);
		ArticleStatusResponse twitterStatusResponse = new ArticleStatusResponse();
		twitterStatusResponse.setReply_articles(null);
		twitterStatusResponse.setAuthor_user_name(loginId);
		twitterStatusResponse.setUser(data);
		twitterStatusResponse.setArticle_type("like");
		twitterStatusResponse.setEvent_type("UPDATE");
		twitterStatusResponse.setArticle_id("a1");
		twitterStatusResponse.setReply_articles(replyArticles);
		Mockito.when(articleOperationRepository.searchArticleById(twitterStatusResponse.getArticle_id())).thenReturn(db);
		Mockito.when(userOperationRepository.searchUserByEmail(loginId)).thenReturn(registrationlist);
		assertNotNull(tweetServiceImpl.replyArticles(twitterStatusResponse));
	}
	@Test
	public void replyTweetsTestNullReply() throws BaseClassException
	{
		String loginId = "mala";
		List<RegistrationData> registrationlist = new ArrayList<RegistrationData>();
		RegistrationData data = new RegistrationData();
		data.setLoginId(loginId);
		registrationlist.add(data);
		ReplyArticle replyArticle = new ReplyArticle();
		ReplyArticles replyArticles = new ReplyArticles();
		replyArticles.setReplyCount(SocioAppConstants.NUM1);
		List<ReplyArticle> replyList = new ArrayList<>();
		replyList.add(replyArticle);
		replyArticles.setReplyArticleList(replyList);
		ArticleStatusResponseDB db = new ArticleStatusResponseDB();
		ArticleStatusResponse twitterStatusResponse = new ArticleStatusResponse();
		twitterStatusResponse.setReply_articles(null);
		twitterStatusResponse.setAuthor_user_name(loginId);
		twitterStatusResponse.setUser(data);
		twitterStatusResponse.setArticle_type("REPLY");
		twitterStatusResponse.setEvent_type("UPDATE");
		twitterStatusResponse.setArticle_id("a1");
		twitterStatusResponse.setReply_articles(null);
		Mockito.when(articleOperationRepository.searchArticleById(twitterStatusResponse.getArticle_id())).thenReturn(db);
		Mockito.when(userOperationRepository.searchUserByEmail(loginId)).thenReturn(registrationlist);
		assertNotNull(tweetServiceImpl.replyArticles(twitterStatusResponse));
	}
	@Test
	public void favouriteTest() throws BaseClassException
	{
		String loginId = "mala";
		List<RegistrationData> registrationlist = new ArrayList<RegistrationData>();
		RegistrationData data = new RegistrationData();
		data.setLoginId(loginId);
		registrationlist.add(data);
		ReplyArticle replyArticle = new ReplyArticle();
		ReplyArticles replyArticles = new ReplyArticles();
		replyArticles.setReplyCount(SocioAppConstants.NUM1);
		List<ReplyArticle> replyList = new ArrayList<>();
		replyList.add(replyArticle);
		replyArticles.setReplyArticleList(replyList);
		ArticleStatusResponseDB db = new ArticleStatusResponseDB();
		
		ArticleStatusResponse twitterStatusResponse = new ArticleStatusResponse();
		twitterStatusResponse.setReply_articles(null);
		twitterStatusResponse.setAuthor_user_name(loginId);
		twitterStatusResponse.setUser(data);
		twitterStatusResponse.setArticle_type("REPLY");
		twitterStatusResponse.setEvent_type("LIKE");
		twitterStatusResponse.setArticle_id("a1");
		twitterStatusResponse.setReply_articles(null);
		Mockito.when(articleOperationRepository.searchArticleById(twitterStatusResponse.getArticle_id())).thenReturn(db);
		assertNotNull(tweetServiceImpl.favouriteArticles(twitterStatusResponse, loginId));
	}
	@Test
	public void favouriteTestEvent() throws BaseClassException
	{
		String loginId = "mala";
		List<RegistrationData> registrationlist = new ArrayList<RegistrationData>();
		RegistrationData data = new RegistrationData();
		data.setLoginId(loginId);
		registrationlist.add(data);
		ReplyArticle replyArticle = new ReplyArticle();
		ReplyArticles replyArticles = new ReplyArticles();
		replyArticles.setReplyCount(SocioAppConstants.NUM1);
		List<ReplyArticle> replyList = new ArrayList<>();
		replyList.add(replyArticle);
		replyArticles.setReplyArticleList(replyList);
		ArticleStatusResponseDB db = new ArticleStatusResponseDB();
		
		ArticleStatusResponse twitterStatusResponse = new ArticleStatusResponse();
		twitterStatusResponse.setReply_articles(null);
		twitterStatusResponse.setAuthor_user_name(loginId);
		twitterStatusResponse.setUser(data);
		twitterStatusResponse.setArticle_type("REPLY");
		twitterStatusResponse.setEvent_type("dLIKE");
		twitterStatusResponse.setArticle_id("a1");
		twitterStatusResponse.setReply_articles(null);
		Mockito.when(articleOperationRepository.searchArticleById(twitterStatusResponse.getArticle_id())).thenReturn(db);
		assertNotNull(tweetServiceImpl.favouriteArticles(twitterStatusResponse, loginId));
	}
	@Test
	public void favouriteTestUpCounter() throws BaseClassException
	{
		String loginId = "mala";
		List<RegistrationData> registrationlist = new ArrayList<RegistrationData>();
		RegistrationData data = new RegistrationData();
		data.setLoginId(loginId);
		registrationlist.add(data);
		ReplyArticle replyArticle = new ReplyArticle();
		ReplyArticles replyArticles = new ReplyArticles();
		replyArticles.setReplyCount(SocioAppConstants.NUM1);
		List<ReplyArticle> replyList = new ArrayList<>();
		replyList.add(replyArticle);
		replyArticles.setReplyArticleList(replyList);
		FavouriteArticles favs = new FavouriteArticles();
		favs.setFavouriteCount(1);
		favs.setFavouriteArticleList(new ArrayList<FavouriteArticle>());
		ArticleStatusResponseDB db = new ArticleStatusResponseDB();
		db.setFavouriteArticles(favs);
		ArticleStatusResponse twitterStatusResponse = new ArticleStatusResponse();
		twitterStatusResponse.setReply_articles(null);
		twitterStatusResponse.setAuthor_user_name(loginId);
		twitterStatusResponse.setUser(data);
		twitterStatusResponse.setArticle_type("REPLY");
		twitterStatusResponse.setEvent_type("LIKE");
		twitterStatusResponse.setArticle_id("a1");
		twitterStatusResponse.setReply_articles(null);
		Mockito.when(articleOperationRepository.searchArticleById(twitterStatusResponse.getArticle_id())).thenReturn(db);
		assertNotNull(tweetServiceImpl.favouriteArticles(twitterStatusResponse, loginId));
	}
}
