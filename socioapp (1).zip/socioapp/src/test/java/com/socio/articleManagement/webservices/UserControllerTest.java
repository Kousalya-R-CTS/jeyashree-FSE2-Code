package com.socio.articleManagement.webservices;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.socio.articleManagement.exception.BaseClassException;
import com.socio.articleManagement.models.RegistrationData;
import com.socio.articleManagement.models.ResponseGateway;
import com.socio.articleManagement.repository.UserOperationRepository;
import com.socio.articleManagement.service.IUserService;

@RunWith(MockitoJUnitRunner.Silent.class)
public class UserControllerTest {
	/**
	 * holds UserService reference
	 */
	@Mock
	private IUserService userService;
	/**
	 * holds UserService reference
	 */
	@Mock
	private UserOperationRepository userOperationRepository;
	@InjectMocks
	private UserController userController;
	
	@Test
	public void saveTweets() throws BaseClassException, ParseException
	{
		Mockito.when(userService.saveUser(null)).thenReturn(new RegistrationData());
		ResponseEntity<ResponseGateway> res = userController.createUser(null, null);
		assertNotNull(res);
	}
	@Test
	public void saveTweetsNull() throws BaseClassException, ParseException
	{
		Mockito.when(userService.saveUser(null)).thenReturn(null);
		ResponseEntity<ResponseGateway> res = userController.createUser(null, null);
		assertNotNull(res);
	}
	@Test
	public void saveTweetsException() throws BaseClassException, ParseException
	{
		userController.setUserService(null);
		ResponseEntity<ResponseGateway> res = userController.createUser(null, null);
		assertNull(res);
	}
	@Test
	public void loginTweets() throws BaseClassException, ParseException
	{
		Mockito.when(userService.getLoginStatus(null, null)).thenReturn(new RegistrationData());
		ResponseEntity<ResponseGateway> res = userController.getLoginStatus(null, null, null);
		assertNotNull(res);
	}
	@Test
	public void loginTweetsNull() throws BaseClassException, ParseException
	{
		Mockito.when(userService.getLoginStatus(null, null)).thenReturn(null);
		ResponseEntity<ResponseGateway> res = userController.getLoginStatus(null, null, null);
		assertNotNull(res);
	}
	@Test
	public void loginTweetsException() throws BaseClassException, ParseException
	{
		userController.setUserService(null);
		ResponseEntity<ResponseGateway> res = userController.getLoginStatus(null, null, null);
		assertNull(res);
	}
	@Test
	public void updateUser() throws BaseClassException, ParseException
	{
		Mockito.when(userService.updateUser(null)).thenReturn(new RegistrationData());
		ResponseEntity<ResponseGateway> res = userController.updateUser(null, null, null);
		assertNotNull(res);
	}
	@Test
	public void updateUserNull() throws BaseClassException, ParseException
	{
		Mockito.when(userService.updateUser(null)).thenReturn(null);
		ResponseEntity<ResponseGateway> res = userController.updateUser(null, null, null);
		assertNotNull(res);
	}
	@Test
	public void updateUsersException() throws BaseClassException, ParseException
	{
		userController.setUserService(null);
		ResponseEntity<ResponseGateway> res = userController.updateUser(null, null, null);
		assertNull(res);
	}
	@Test
	public void searchAllTest() throws BaseClassException, ParseException
	{
		
		Mockito.when(userOperationRepository.searchUserByEmail(null)).thenReturn(new ArrayList<RegistrationData>());
		ResponseEntity<ResponseGateway> res = userController.searchUserName(null, null);
		assertNotNull(res);
	}
	@Test
	public void searchAllTestNull() throws BaseClassException, ParseException
	{
		
		Mockito.when(userOperationRepository.searchUserByEmail(null)).thenReturn(null);
		ResponseEntity<ResponseGateway> res = userController.searchUserName(null, null);
		assertNotNull(res);
	}
	@Test
	public void searchAllTestException() throws BaseClassException, ParseException
	{
		userController.setUserService(null);
		ResponseEntity<ResponseGateway> res = userController.searchUserName(null, null);
		assertNotNull(res);
	}
	@Test
	public void searchUserTest() throws BaseClassException, ParseException
	{
		
		Mockito.when(userOperationRepository.findAll()).thenReturn(new ArrayList<RegistrationData>());
		ResponseEntity<ResponseGateway> res = userController.searchUsers(null);
		assertNotNull(res);
	}
	@Test
	public void searchUserTestNull() throws BaseClassException, ParseException
	{
		
		Mockito.when(userOperationRepository.findAll()).thenReturn(null);
		ResponseEntity<ResponseGateway> res = userController.searchUsers(null);
		assertNotNull(res);
	}
	@Test
	public void searchUserTestException() throws BaseClassException, ParseException
	{
		userController.setUserService(null);
		ResponseEntity<ResponseGateway> res = userController.searchUsers(null);
		assertNotNull(res);
	}
	
	
}
