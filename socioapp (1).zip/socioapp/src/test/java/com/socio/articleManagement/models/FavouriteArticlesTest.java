package com.socio.articleManagement.models;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class FavouriteArticlesTest {

	
	@Test
	public void favouriteTweetsTest()
	{
		new BeanTester().testBean(FavouriteArticles.class);
		assertNotNull(new FavouriteArticles());
	}
	
}
