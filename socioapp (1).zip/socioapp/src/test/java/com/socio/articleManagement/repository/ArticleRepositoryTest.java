package com.socio.articleManagement.repository;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;

import com.socio.articleManagement.models.ReplyArticle;
import com.socio.articleManagement.models.ReplyArticles;
import com.socio.articleManagement.util.SocioAppConstants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.socio.articleManagement.exception.BaseClassException;
import com.socio.articleManagement.models.ArticleStatusResponseDB;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ArticleRepositoryTest
{
	@Mock
	private MongoTemplate mongoTemplate;
	

	@Mock
	ObjectMapper objectMapper;
	@InjectMocks
	private ArticleRepository repository;
	


	@Test
	public void getUserTweets() throws BaseClassException
	{
		ArticleStatusResponseDB twitterStatusResponse = new ArticleStatusResponseDB();
		twitterStatusResponse.setArticleId("ki");
		String id = "ij";
		ArticleStatusResponseDB value = new ArticleStatusResponseDB();
		ReplyArticle replyArticle = new ReplyArticle();
		ReplyArticles replyArticles = new ReplyArticles();
		replyArticles.setReplyCount(SocioAppConstants.NUM1);
		List<ReplyArticle> replyList = new ArrayList<>();
		replyList.add(replyArticle);
		replyArticles.setReplyArticleList(replyList);
		value.setReplyArticles(replyArticles);
		List<ArticleStatusResponseDB> tweets = new ArrayList<ArticleStatusResponseDB>();
		tweets.add(value);
		Mockito.when(repository.getArticleDetailById(id)).thenReturn(value);
		Mockito.when(mongoTemplate.find(null, ArticleStatusResponseDB.class, "tweet_detail")).thenReturn(tweets);
		Mockito.when(mongoTemplate.findOne(null, ArticleStatusResponseDB.class)).thenReturn(value);
		
		tweets = repository.getUserArticles(id, null, null);
		assertNotNull(tweets);
	}
	@Test
	public void getUserTweetsReplyNull() throws BaseClassException
	{
		ArticleStatusResponseDB twitterStatusResponse = new ArticleStatusResponseDB();
		twitterStatusResponse.setArticleId("ki");
		String id = "ij";
		ArticleStatusResponseDB value = new ArticleStatusResponseDB();
		ReplyArticle replyArticle = new ReplyArticle();
		ReplyArticles replyArticles = new ReplyArticles();
		replyArticles.setReplyCount(SocioAppConstants.NUM1);
		List<ReplyArticle> replyList = new ArrayList<>();
		replyList.add(replyArticle);
		List<ArticleStatusResponseDB> tweets = new ArrayList<ArticleStatusResponseDB>();
		tweets.add(value);
		Mockito.when(repository.getArticleDetailById(id)).thenReturn(value);
		Mockito.when(mongoTemplate.find(null, ArticleStatusResponseDB.class, "tweet_detail")).thenReturn(tweets);
		Mockito.when(mongoTemplate.findOne(null, ArticleStatusResponseDB.class)).thenReturn(value);
		
		tweets = repository.getUserArticles(id, null, null);
		assertNull(tweets);
	}
	@Test
	public void getUserTweetsName() throws BaseClassException
	{
		ArticleStatusResponseDB twitterStatusResponse = new ArticleStatusResponseDB();
		twitterStatusResponse.setArticleId("ki");
		String name = "ij";
		ArticleStatusResponseDB value = new ArticleStatusResponseDB();
		ReplyArticle replyArticle = new ReplyArticle();
		ReplyArticles replyArticles = new ReplyArticles();
		replyArticles.setReplyCount(SocioAppConstants.NUM1);
		List<ReplyArticle> replyList = new ArrayList<>();
		replyList.add(replyArticle);
		replyArticles.setReplyArticleList(replyList);
		value.setReplyArticles(replyArticles);
		List<ArticleStatusResponseDB> tweets = new ArrayList<ArticleStatusResponseDB>();
		tweets.add(value);
		
		Mockito.when(mongoTemplate.find(null, ArticleStatusResponseDB.class, "tweet_detail")).thenReturn(tweets);
		Mockito.when(mongoTemplate.findOne(null, ArticleStatusResponseDB.class)).thenReturn(value);
		tweets = repository.getUserArticles(null, name, null);
		assertNotNull(tweets);
	}
	@Test
	public void getUserTweetsThreadId() throws BaseClassException
	{
		String id = "ij";
		ArticleStatusResponseDB twitterStatusResponse = new ArticleStatusResponseDB();
		twitterStatusResponse.setArticleId(id);
		ArticleStatusResponseDB value = new ArticleStatusResponseDB();
		value.setEventType("ORIGIN");
		List<ArticleStatusResponseDB> tweets = new ArrayList<ArticleStatusResponseDB>();
		tweets.add(value);
		Mockito.when(mongoTemplate.find(null, ArticleStatusResponseDB.class, "tweet_detail")).thenReturn(tweets);
		Mockito.when(mongoTemplate.findOne(null, ArticleStatusResponseDB.class)).thenReturn(value);
		Mockito.when(repository.extractedOriginalArticle(twitterStatusResponse)).thenReturn(value);
		tweets = repository.getUserArticles(null, null, id);
		assertNotNull(tweets);
	}
}
