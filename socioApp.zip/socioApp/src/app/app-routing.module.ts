import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { ArticleComponent } from './components/article/article.component';
import { UsersComponent } from './components/users/users.component';
import { MaterialDialogReplyArticleComponent } from './components/material-dialog-reply-article/material-dialog-reply-article.component';


const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  {path: 'login', component: LoginComponent},
  {path: 'home/:id', component: HomeComponent, children: [
    {path: '', redirectTo: 'articles', pathMatch: 'full' },
    {path: 'articles', component: ArticleComponent},
    {path: 'users', component: UsersComponent}, 
    {path: 'reply', component: MaterialDialogReplyArticleComponent},
    {path: 'forgotPassword', component: ForgotPasswordComponent}
  ]},
  {path: 'register', component: RegistrationComponent},
  {path: 'forgotPassword', component: ForgotPasswordComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
