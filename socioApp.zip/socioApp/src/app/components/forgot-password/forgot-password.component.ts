import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup,Validators,FormControl} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MaterialDialogComponent } from '../material-dialog/material-dialog.component';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';
import { Data } from '../../models/data';
import { Result } from 'src/app/models/result';
import { Model } from 'src/app/models/model';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css'],
})
export class ForgotPasswordComponent implements OnInit {
  submitted = false;
  model: Model = new Model();
  id: any;
  isLogin = true;
  user: Data = new Data('', '', '', '', '', '');
  reset: Data = new Data('', '', '', '', '', '');
  resp: Result = new Result();
  resetForm = new FormGroup({
    email: new FormControl(''),
    userName: new FormControl(''),
    password: new FormControl(''),
    confirmPassword: new FormControl(''),
  });
  constructor(
    private formBuilder: FormBuilder,
    private userService: UserService,
    private router: Router,
    private matDialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.id = sessionStorage.getItem('username');
    this.isLogin = true;
    this.resetForm = this.formBuilder.group(
      {
        email: ['', [Validators.required, Validators.email]],
        userName: ['', [Validators.required]],
        password: ['', [Validators.required, Validators.minLength(6)]],
        confirmPassword: ['', Validators.required],
      },
      {
        validator: MustMatch('password', 'confirmPassword'),
      }
    );
    this.viewUser(this.id);
  }
  /**
   * To view user profile details
   * @param user  
   */
  viewUser(user: any) {
    if (undefined != this.id || null != this.id) {
      this.userService.searchUserName(user).subscribe((data) => {
        this.user = data.data[0];
        
        this.isLogin = false;
        this.fillDetailsForLogin();
      });
    }
  }
  /**
   * For logged in user defaultvalues are prefilled
   */
  fillDetailsForLogin() {
    if (undefined != this.id || null != this.id) {
      this.resetForm.setValue({
        email: this.user.email,
        userName: this.user.loginId,
        password: '',
        confirmPassword: '',
      });
    }
  }
  /**
   * For showing success message
   * @param model 
   */
  openDialog(model: Model) {
    const dialogRef = this.matDialog.open(MaterialDialogComponent, {
      width: '450px',
      height: '200px',
      data: model,
      restoreFocus: false,
    });
    // Manually restore focus to the menu trigger since the element that
    // opens the dialog won't be in the DOM any more when the dialog closes.
    dialogRef.afterClosed().subscribe(() => {
      this.resetForm.reset();
      this.submitted = false;
    });
  }
  // convenience getter for easy access to form fields
  get f() {
    return this.resetForm.controls;
  }
  /**
   * After submit form
   * @param dataValue 
   */
  onSubmit(dataValue: any) {
    this.submitted = true;
    // stop here if form is invalid
    if (this.resetForm.invalid) {
      return;
    } else if (this.resetForm.valid) {
      this.submitted = false;
      this.reset = new Data(
        '',
        '',
        dataValue.userName,
        '',
        dataValue.email,
        dataValue.password
      );
        /**
         * for update pwd
         */
      this.userService.updatePassword(this.reset).subscribe(
        (response) => {
          this.resp = response;
          if (this.resp.statusCode == '200') {
            this.model.content = 'Password Changed Successfully';
            this.model.title = 'Reset Password';
            this.openDialog(this.model);
            this.router.navigate(['login']);
          } 
          //If user inputs invalid input
          else {
            this.model.content =
              'Please provide with valid user name and email';
            this.model.title = 'Reset Password';
            this.openDialog(this.model);
          }
        },
        (error) => {}
      );
    }
  }
}
// custom validator to check that two fields match
export function MustMatch(controlName: string, matchingControlName: string) {
  return (formGroup: FormGroup) => {
    const control = formGroup.controls[controlName];
    const matchingControl = formGroup.controls[matchingControlName];

    if (matchingControl.errors && !matchingControl.errors.mustMatch) {
      // return if another validator has already found an error on the matchingControl
      return;
    }

    // set error on matchingControl if validation fails
    if (control.value !== matchingControl.value) {
      matchingControl.setErrors({ mustMatch: true });
    } else {
      matchingControl.setErrors(null);
    }
  };
}
