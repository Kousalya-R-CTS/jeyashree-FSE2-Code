import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl,
} from '@angular/forms';
import { Data } from 'src/app/models/data';
import { Article } from 'src/app/models/article';
import { articles } from 'src/app/models/articles';
import { ArticleService } from 'src/app/services/article.service';
import { UserService } from 'src/app/services/user.service';
import { MaterialDialogReplyArticleComponent } from '../material-dialog-reply-article/material-dialog-reply-article.component';

@Component({
  selector: 'app-Article',
  templateUrl: './Article.component.html',
  styleUrls: ['./Article.component.css'],
})
export class ArticleComponent implements OnInit {
  loginDetail: Data = new Data('', '', '', '', '', '');
  replyArticle: Article = new Article();
  isLoad: boolean = true;
  isUser: boolean = false;
  profileName: string = '';
  isArticles: boolean = false;
  userNames: String[] = [];
  ArticleList: Article[] = [];
  likeCount: number = 0;
  hidden = false;
  submitted = false;
  id: any = '';
  userId: String[] = [];
  user: Data = new Data('', '', '', '', '', '');
  ArticleResponse: articles = new articles(new Array<Article>());
  ArticleForm = new FormGroup({
    ArticleText: new FormControl(''),
  });
  constructor(
    private userService: UserService,
    private formBuilder: FormBuilder,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private ArticleService: ArticleService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.id = sessionStorage.getItem('username');
    
    this.ArticleService.getAllArticles().subscribe((data) => {
      this.isUser = false;
      this.isArticles = true;
      this.ArticleResponse.articles = data.data.articles;
      this.isLoad = false;
      this.ArticleList = this.ArticleResponse.articles;
    });
 
    //For logged in user detail
    this.getloginDetail(this.id);
    this.isUser = true;
    this.isArticles = false;
    this.isLoad = true;
    this.submitted = false;
    this.userService.getUserId().subscribe((data) => {
      this.userId = data.data;
    });
    this.ArticleForm = this.formBuilder.group({
      ArticleText: ['', [Validators.maxLength(144), Validators.minLength(1)]],
    });
  }
  /**
   * update user Article
   * @param user 
   */
  updateArticles(user: Article) {
    user.eventType = 'UPDATEArticle';
    this.openDialog(user);
  }
  /**
   * to get login user details
   * @param id 
   */
  getloginDetail(id: any) {
    this.userService.searchUserName(id).subscribe((data) => {
      this.loginDetail = data.data[0];
    });
  }
  // convenience getter for easy access to form fields
  get f() {
    return this.ArticleForm.controls;
  }
  //submit form
  onSubmit(formValue: any) {
    console.log("11")
    this.submitted = true;

    // stop here if form is invalid
    if (this.ArticleForm.invalid) {
      return;
    } else if (this.ArticleForm.valid && formValue.ArticleText.length > 0) {
      this.isLoad = true;
     
      this.replyArticle.text = formValue.ArticleText;
      this.replyArticle.articleType = 'ORIGINAL';
      this.replyArticle.authorUserName = this.id;
      this.replyArticle.eventType = 'NEW';
      this.replyArticle.userName = this.id;
      this.replyArticle.user = this.loginDetail;
      //For service call
      this.ArticleService.saveArticle(this.replyArticle).subscribe((data) => {
        this.isLoad = false;
        this.ArticleForm.reset();
        this.submitted = false;
        //After save 
        this.viewAllArticles();
      });

    }
  }

  /**
   * to view Articles
   * @param user
   */
  viewAllArticles() {
    this.ArticleService.getAllArticles().subscribe((data) => {
      this.isUser = false;
      this.isArticles = true;
      this.ArticleResponse.articles = data.data.articles;
      this.isLoad = false;
      this.ArticleList = this.ArticleResponse.articles;
    });
  }
  /**
   * To upvote/like the Article
   * @param user
   */
  favourites(user: Article) {
    var isLike = false;
    user.eventType = 'LIKE';

    //For prevent more likes by  user who already liked that Article
    if (undefined != user.favouriteArticles && null != user.favouriteArticles && null != user.favouriteArticles.favouriteArticleList) {
      for (var i = 0; i < user.favouriteArticles.favouriteArticleList.length; i++) {
        if (
          user.favouriteArticles.favouriteArticleList[i].favouriteUserName == this.id
        ) {
          isLike = true;
        }
      }
    }
    if (!isLike) {
      this.ArticleService
        .favoriteArticles(this.id, user.articleId, user)
        .subscribe((data) => {
          this.viewAllArticles();
        });
    }
  }
  //Delete Article only for author users and login user same
  deleteArticle(user: Article) {
    this.ArticleService
      .deleteArticle(user)
      .subscribe((data) => this.viewAllArticles());
  }
  /**
   * To reply Article
   * @param user
   */
  replyArticles(user: Article) {
    console.log("reply"+user.articleId);
    this.openDialog(user);
    if (undefined != user.replyArticleList || null != user.replyArticleList) {
      this.ArticleService
        .getUserArticles('', user.articleId, '', user.createdAt)
        .subscribe((data) => {
        });
    }
  }
  //open reply Articles 
  openDialog(user: Article) {
    const dialogRef = this.dialog.open(MaterialDialogReplyArticleComponent, {
      width: '750px',
      height: '500px',
      data: user,
      restoreFocus: false,
    });

    // Manually restore focus to the menu trigger since the element that
    // opens the dialog won't be in the DOM any more when the dialog closes.
    dialogRef.afterClosed().subscribe(() => this.viewAllArticles());
  }
}
