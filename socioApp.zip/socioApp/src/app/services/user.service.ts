import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Result } from '../models/result';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Todo } from '../components/login/login.component';
import { AbstractControl,FormControl } from '@angular/forms';
import { Data } from '../models/data';
import { Userresponse } from '../models/userresponse';
import { ServiceConstants } from '../constants/serviceConstants';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  result: Result = new Result;
  resp: Userresponse = new Userresponse([]);
  arr : String[] = [];
  constructor(private http: HttpClient) {
    
   }
 url = ServiceConstants.apiURL;
 
  searchUserName(user : any)
  {
    var userUrl = this.url + ServiceConstants.searchUserArticleUrl + ServiceConstants.userArticleEndPoint + 
      '?' + ServiceConstants.paramName + user;
    return this.http.get<Result>(userUrl,); 
  }
  createUser(register : Data)
  {
    var tempUrl = this.url + 'register';
    return this.http.post(tempUrl, register);
  }
  checkLogin(userName : String, password : String) 
  {
    var loginUrl = this.url + ServiceConstants.loginEndPoint +
           '?' + 'userName=' + userName + '&' + 'password=' +password; 
    
    return this.http.get<Result>(loginUrl,);
  }
  updatePassword(resetData : Data): Observable<Result> {
    var url = this.url + resetData.loginId + '/'+ServiceConstants.resetEndPoint 
    return this.http.put<Result>(url ,resetData)
  }

  
  getUserId()
  {
    var tempUrl = this.url + 'users' + '/' + 'all';
    return this.http.get<Userresponse>(tempUrl);
  }
}
