import { FavouriteArticle } from "./favouriteArticle";

export class FavouriteArticles
{
    favouriteCount : number =0;
    favouriteArticleList : FavouriteArticle[] =[];
    
}