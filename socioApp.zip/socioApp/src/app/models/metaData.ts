export class Metadata{
    totalCount : number =0;
    resultCount : number =0;
    offset : number =0;

}