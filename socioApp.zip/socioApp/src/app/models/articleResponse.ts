import { articles } from "./articles";

export class ArticleResponse {
    data : articles;
    statusCode : String = '';
    constructor(data : articles)
    {
        this.data = data;
    }
}
