export class Userresponse {
    data : String[] = [];
    statusCode : String='';
    constructor(data : String[])
    {
        this.data = data;
    }
}
