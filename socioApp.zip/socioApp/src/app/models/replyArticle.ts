export class ReplyArticle 
{
    threadId : String ='';
    replyUserName : String ='';
    originalArticleId : String ='';
    replyAt : String ='';
    articleId : String ='';
}